using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Lab23.Services;
using Lab23.ViewModels;
using Lab23.Views;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Lab23;

public partial class App : Application
{
    // 5.1.2 свойство Configuration
    public static IConfiguration Configuration { get; private set; } = null!;

    // 5.2.2 свойство Services
    public static ServiceProvider Services { get; private set; } = null!;

    public override void Initialize() => AvaloniaXamlLoader.Load(this);

    public override void OnFrameworkInitializationCompleted()
    {
        // 5.1.4 ConfigurationBuilder
        var builder = new ConfigurationBuilder();
        builder.AddJsonFile("appsettings.json");
        Configuration = builder.Build();

        // 5.2.1 ServiceCollection
        var collection = new ServiceCollection();

        // 5.3.3 регистрация сервисов
        collection.AddSingleton<NavigationService>();
        collection.AddSingleton<MainWindowViewModel>();
        collection.AddTransient<RegistrationViewModel>();
        collection.AddTransient<AuthorizationViewModel>();

        Services = collection.BuildServiceProvider();

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var mainVm = Services.GetRequiredService<MainWindowViewModel>();
            desktop.MainWindow = new MainWindow { DataContext = mainVm };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
