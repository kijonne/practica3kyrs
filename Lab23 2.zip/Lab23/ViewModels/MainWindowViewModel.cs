using CommunityToolkit.Mvvm.Input;
using Lab23.Services;
using System.ComponentModel;

namespace Lab23.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;

    // 5.4.3 CurrentPage берётся напрямую из навигации
    public ViewModelBase? CurrentPage => _navigation.Current;

    // 5.4.1 NavigationService внедряется через конструктор
    public MainWindowViewModel(NavigationService navigation)
    {
        _navigation = navigation;

        // 5.4.4 подписка на PropertyChanged навигации
        _navigation.PropertyChanged += navigation_PropertyChanged;

        // начальная страница — авторизация (через DI)
        _navigation.NavigateTo<AuthorizationViewModel>();
    }

    // 5.4.4 обработчик — обновляет CurrentPage
    private void navigation_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        OnPropertyChanged(nameof(CurrentPage));
    }

    [RelayCommand]
    private void GoToAuthorization() => _navigation.NavigateTo<AuthorizationViewModel>();

    [RelayCommand]
    private void GoToRegistration() => _navigation.NavigateTo<RegistrationViewModel>();

    [RelayCommand]
    private void GoBack() => _navigation.GoBack();
}
