using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab23.Services;

namespace Lab23.ViewModels;

public partial class RegistrationViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;

    [ObservableProperty] private string login = "";
    [ObservableProperty] private string password = "";

    // 5.4.1 NavigationService через конструктор
    public RegistrationViewModel(NavigationService navigation)
    {
        _navigation = navigation;
    }

    [RelayCommand]
    private void Register() { /* заглушка */ }

    // 5.4.2 переход на авторизацию с передачей логина
    [RelayCommand]
    private void GoToAuthorization() =>
        _navigation.NavigateTo<AuthorizationViewModel>(x => x.Login = this.Login);

    [RelayCommand]
    private void GoBack() => _navigation.GoBack();
}
