using CommunityToolkit.Mvvm.ComponentModel;

namespace Lab23.ViewModels;

public partial class ViewModelBase : ObservableObject { }
