using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab23.Services;

namespace Lab23.ViewModels;

public partial class AuthorizationViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;

    [ObservableProperty] private string login = "";
    [ObservableProperty] private string password = "";

    // 5.5 — для демонстрации конвертера
    [ObservableProperty] private double celsius = 100;

    // 5.4.1 NavigationService через конструктор
    public AuthorizationViewModel(NavigationService navigation)
    {
        _navigation = navigation;
    }

    [RelayCommand]
    private void Login() { /* заглушка */ }

    // 5.4.2 переход на регистрацию с передачей логина
    [RelayCommand]
    private void GoToRegistration() =>
        _navigation.NavigateTo<RegistrationViewModel>(x => x.Login = this.Login);

    [RelayCommand]
    private void GoBack() => _navigation.GoBack();
}
