using Avalonia.Data.Converters;
using System;
using System.Globalization;

namespace Lab23.Converters;

// 5.5.1 конвертер градусов Цельсия в Фаренгейт
public class CelsiusToFarenhateConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value == null) return null;
        double celsius = System.Convert.ToDouble(value);
        // преобразуем из градусов C в градусы F
        return Math.Round(celsius * 9.0 / 5.0 + 32, 2);
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value == null) return null;
        double fahrenheit = System.Convert.ToDouble(value);
        // преобразуем из градусов F в градусы C
        return Math.Round((fahrenheit - 32) * 5.0 / 9.0, 2);
    }
}
