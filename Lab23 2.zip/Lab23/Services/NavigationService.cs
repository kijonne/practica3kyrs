using CommunityToolkit.Mvvm.ComponentModel;
using Lab23.ViewModels;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;

namespace Lab23.Services;

// 5.3.1 наследуем ObservableObject, вызываем OnPropertyChanged для Current
public class NavigationService : ObservableObject
{
    private readonly Stack<ViewModelBase> _stack = new();

    // текущая вершина стека
    public ViewModelBase? Current => _stack.Count > 0 ? _stack.Peek() : null;

    // оригинальный метод из ПР3
    public void NavigateTo<T>(T viewModel, Action<T>? action = null) where T : ViewModelBase
    {
        action?.Invoke(viewModel);
        _stack.Push(viewModel);
        // 5.3.1 уведомляем об изменении Current
        OnPropertyChanged(nameof(Current));
    }

    // 5.3.2 перегруженный метод — получает страницу через DI
    public void NavigateTo<T>(Action<T>? action = null) where T : ViewModelBase
    {
        var viewModel = App.Services.GetRequiredService<T>();
        NavigateTo(viewModel, action);
    }

    public void GoBack(int steps = 1)
    {
        for (int i = 0; i < steps; i++)
        {
            if (_stack.Count > 1)
                _stack.Pop();
        }
        // 5.3.1 уведомляем об изменении Current
        OnPropertyChanged(nameof(Current));
    }
}
