using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lab23.Views;

public partial class RegistrationView : UserControl
{
    public RegistrationView() => AvaloniaXamlLoader.Load(this);
}
