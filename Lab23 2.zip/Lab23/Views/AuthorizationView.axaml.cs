using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lab23.Views;

public partial class AuthorizationView : UserControl
{
    public AuthorizationView() => AvaloniaXamlLoader.Load(this);
}
