using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lab23.Views;

public partial class MainWindow : Window
{
    public MainWindow() => AvaloniaXamlLoader.Load(this);
}
