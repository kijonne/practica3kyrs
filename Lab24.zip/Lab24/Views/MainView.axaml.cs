using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lab24.Views;

public partial class MainView : UserControl
{
    public MainView() => AvaloniaXamlLoader.Load(this);
}
