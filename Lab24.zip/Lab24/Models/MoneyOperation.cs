namespace Lab24.Models;

public class MoneyOperation
{
    // описание операции
    public string Description { get; set; } = string.Empty;

    // сумма
    public decimal Amount { get; set; }

    // является ли операция доходом (true) или расходом (false)
    public bool IsIncome { get; set; }
}
