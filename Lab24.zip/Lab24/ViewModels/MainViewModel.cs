using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using Lab24.Models;

namespace Lab24.ViewModels;

public partial class MainViewModel : ObservableObject
{
    // список операций для п. 5.3.3
    public ObservableCollection<MoneyOperation> Operations { get; } =
    [
        new MoneyOperation { Description = "Зарплата",     Amount = 50000, IsIncome = true  },
        new MoneyOperation { Description = "Аренда",       Amount = 15000, IsIncome = false },
        new MoneyOperation { Description = "Фриланс",      Amount = 12000, IsIncome = true  },
        new MoneyOperation { Description = "Продукты",     Amount = 5000,  IsIncome = false },
        new MoneyOperation { Description = "Инвестиции",   Amount = 8000,  IsIncome = true  },
        new MoneyOperation { Description = "Коммуналка",   Amount = 3000,  IsIncome = false },
    ];
}
