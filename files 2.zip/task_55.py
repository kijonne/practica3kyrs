import threading
import time
import random

# 5.5 Сервер: одновременно только 3 запроса, 10 пользователей

semaphore = threading.Semaphore(3)

def request_handler(user_id):
    print(f'Пользователь {user_id} ждет доступа')
    semaphore.acquire()
    print(f'Пользователь {user_id} подключился к серверу')
    time.sleep(random.randint(1, 3))
    print(f'Пользователь {user_id} отключился')
    semaphore.release()

threads = []
for i in range(1, 11):
    t = threading.Thread(target=request_handler, args=(i,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
