import threading
import time

# 5.2 Два потока: числа 0-9 и буквы A-J

def print_numbers():
    for i in range(10):
        print(f'Число: {i}')
        time.sleep(2)

def print_letters():
    for ch in 'ABCDEFGHIJ':
        print(f'Буква: {ch}')
        time.sleep(2)

t1 = threading.Thread(target=print_numbers)
t2 = threading.Thread(target=print_letters)

t1.start()
t2.start()

t1.join()
t2.join()
