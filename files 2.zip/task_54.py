import threading

# 5.4 То же что 5.3, но с семафором вместо lock

counter = 0
semaphore = threading.Semaphore(1)

def increment(thread_id):
    global counter
    for i in range(11):
        semaphore.acquire()
        if i < 10:
            counter += 1
        else:
            counter = 0
        print(f'Поток {thread_id} меняет counter = {counter}')
        semaphore.release()

threads = []
for i in range(10):
    t = threading.Thread(target=increment, args=(i,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
