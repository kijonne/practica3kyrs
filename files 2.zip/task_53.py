import threading

# 5.3 Глобальная переменная counter, 10 потоков, синхронизация через lock

counter = 0
lock = threading.Lock()

def increment(thread_id):
    global counter
    for i in range(11):
        with lock:
            if i < 10:
                counter += 1
            else:
                counter = 0
            print(f'Поток {thread_id} меняет counter = {counter}')

threads = []
for i in range(10):
    t = threading.Thread(target=increment, args=(i,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
