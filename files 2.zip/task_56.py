import threading
import time

# 5.6 Обмен сообщениями между потоками через Event

event = threading.Event()

def sender():
    print('Отправитель: готовлю сообщение...')
    time.sleep(2)
    print('Отправитель: сообщение отправлено!')
    event.set()

def receiver():
    print('Получатель: жду сообщения...')
    event.wait()
    print('Получатель: сообщение получено!')

t1 = threading.Thread(target=sender)
t2 = threading.Thread(target=receiver)

t2.start()
t1.start()

t1.join()
t2.join()
