import threading
import tkinter as tk
import time

# 5.1 Диспетчер задач
tasks = {}

def run_task(task_id, label_var):
    for i in range(10):
        time.sleep(1)
        if task_id not in tasks:
            return
    if task_id in tasks:
        del tasks[task_id]

def start_task():
    task_id = len(tasks) + 1
    t = threading.Thread(target=run_task, args=(task_id, None), daemon=True)
    tasks[task_id] = t
    t.start()
    update_list()

def stop_task():
    selected = listbox.curselection()
    if selected:
        task_id = int(listbox.get(selected[0]).split()[1])
        if task_id in tasks:
            del tasks[task_id]
        update_list()

def update_list():
    listbox.delete(0, tk.END)
    for tid in tasks:
        listbox.insert(tk.END, f'Процесс {tid} — запущен')
    window.after(1000, update_list)

window = tk.Tk()
window.title('Диспетчер задач')

listbox = tk.Listbox(window, width=40, height=10)
listbox.pack(padx=10, pady=10)

btn_frame = tk.Frame(window)
btn_frame.pack()
tk.Button(btn_frame, text='Запустить', command=start_task).pack(side=tk.LEFT, padx=5)
tk.Button(btn_frame, text='Завершить', command=stop_task).pack(side=tk.LEFT, padx=5)

update_list()
window.mainloop()
