# main_51.py
# Подключение C# модуля FileManager к Python через pythonnet
# Установка: pip install pythonnet
# Сборка dll: csc /target:library FileManager.cs

import clr
import sys

# Указать путь к папке с FileManager.dll
sys.path.append('.')
clr.AddReference('FileManager')

from System import String
from FileManager import FileManager  # type: ignore

fm = FileManager()

# Создание файла
fm.CreateFile('test.txt', 'Привет из C#!\n')

# Чтение файла
content = fm.ReadFile('test.txt')
print('Содержимое:', content)

# Изменение файла
fm.AppendFile('test.txt', 'Дополнительная строка\n')

# Чтение после изменения
content = fm.ReadFile('test.txt')
print('После изменения:', content)

# Удаление файла
fm.DeleteFile('test.txt')

# Проверка после удаления
print(fm.ReadFile('test.txt'))
