# process.py
# Скрипт IronPython, подключаемый к программе на C#
# input_data передаётся из C#

# Получаем данные из C#
numbers = input_data

# Обработка на Python
squared = [x * x for x in numbers]
total = sum(numbers)

# Результат для C#
output = {
    "squared": squared,
    "sum": total,
    "count": len(numbers)
}
