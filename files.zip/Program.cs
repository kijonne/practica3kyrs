// Program.cs
// Программа на C#, подключающая внешний скрипт на IronPython
// Требует: IronPython (установить через NuGet: IronPython)

using System;
using System.Collections.Generic;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

class Program
{
    static void Main()
    {
        ScriptEngine engine = Python.CreateEngine();
        ScriptScope scope = engine.CreateScope();

        // Передаём список чисел в скрипт через переменную input_data
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };
        scope.SetVariable("input_data", numbers);

        // Запускаем скрипт IronPython
        engine.ExecuteFile("process.py", scope);

        // Получаем результат из скрипта
        dynamic output = scope.GetVariable("output");

        Console.WriteLine("Квадраты: " + string.Join(", ", (IEnumerable<object>)output["squared"]));
        Console.WriteLine("Сумма: " + output["sum"]);
        Console.WriteLine("Количество: " + output["count"]);
    }
}
