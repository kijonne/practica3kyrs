// FileManager.cs
// Модуль на C# с методами работы с файловой системой
// Компилируется в FileManager.dll и подключается через Python.NET

using System;
using System.IO;

public class FileManager
{
    // Создание файла с содержимым
    public void CreateFile(string path, string content)
    {
        File.WriteAllText(path, content);
        Console.WriteLine($"Файл создан: {path}");
    }

    // Чтение файла
    public string ReadFile(string path)
    {
        if (!File.Exists(path))
            return "Файл не найден";
        return File.ReadAllText(path);
    }

    // Удаление файла
    public void DeleteFile(string path)
    {
        if (File.Exists(path))
        {
            File.Delete(path);
            Console.WriteLine($"Файл удалён: {path}");
        }
        else
        {
            Console.WriteLine("Файл не найден");
        }
    }

    // Изменение (дозапись) файла
    public void AppendFile(string path, string content)
    {
        File.AppendAllText(path, content);
        Console.WriteLine($"Файл изменён: {path}");
    }
}
